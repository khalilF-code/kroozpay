<?php

$_['heading_title']		= 'KroozPay Payment Gateway';
 
// Text
$_['text_payment']		= 'Payment';
$_['text_success']		= 'Success: all setting saved !';
$_['text_kroozpay']       = '<a href="https://kroozpay.com" target="_blank"><img src="https://kroozpay.com/images/logo.png" style="border: 1px solid #EEEEEE;width: 100px;" /></a>';

$_['text_all_zones']       	= 'All Zones';

// Entry
$_['entry_api']   = 'Api Id:';
$_['entry_key']      = 'Api Key :';

 
$_['entry_status']   = 'Status:'; 
$_['entry_order_status'] = 'Order Status:';
$_['entry_sort_order']   = 'Sort Order:';

$_['entry_geo_zone']     = 'Geo Zone:';


$_['entry_log'] 	 = 'Active log:';


$_['entry_complete']	 = 'Order complete Status:';
$_['entry_canceled']	 = 'Order cancled Status:';


?>